﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Parcial2Test.Models
{
    public partial class Robos
    {

        public int Idrobo { get; set; }
        public string Cedula { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Desc { get; set; }
        public int Valor { get; set; }
        public string UbicacionRobo { get; set; }
        public int Idprovincia { get; set; }
        public float Lat { get; set; }
        public float Lon { get; set; }
    }
}
