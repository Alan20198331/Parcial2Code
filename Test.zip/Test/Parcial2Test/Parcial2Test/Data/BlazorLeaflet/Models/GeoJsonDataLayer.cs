﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorLeaflet.Models
{
    public class GeoJsonDataLayer : InteractiveLayer
    {
        public string GeoJsonData { get; set; }
    }
}
