﻿namespace BlazorLeaflet.Models
{
    public class Polygon : Polyline
    { }
}
