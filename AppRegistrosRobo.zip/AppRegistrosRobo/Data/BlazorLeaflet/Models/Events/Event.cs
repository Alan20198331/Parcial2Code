﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorLeaflet.Models.Events
{
    public class Event
    {
        public string Type { get; set; }
    }
}
