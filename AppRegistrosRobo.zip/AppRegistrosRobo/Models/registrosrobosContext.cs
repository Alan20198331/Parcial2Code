﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace AppRegistrosRobo.Models
{
    public partial class registrosrobosContext : DbContext
    {
        public registrosrobosContext()
        {
        }

        public registrosrobosContext(DbContextOptions<registrosrobosContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Municipios> Municipios { get; set; }
        public virtual DbSet<Provincias> Provincias { get; set; }
        public virtual DbSet<Robos> Robos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("server=localhost;uid=root;pwd=mysql;database=registrosrobos", x => x.ServerVersion("8.0.18-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Municipios>(entity =>
            {
                entity.ToTable("municipios");

                entity.HasIndex(e => e.ProvinciaId)
                    .HasName("ProvinciaId");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Latitud).HasColumnType("float(100,30)");

                entity.Property(e => e.Longitud).HasColumnType("float(100,30)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");

                entity.Property(e => e.ProvinciaId).HasColumnType("int(11)");

                entity.HasOne(d => d.Provincia)
                    .WithMany(p => p.Municipios)
                    .HasForeignKey(d => d.ProvinciaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("municipios_ibfk_1");
            });

            modelBuilder.Entity<Provincias>(entity =>
            {
                entity.ToTable("provincias");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<Robos>(entity =>
            {
                entity.HasKey(e => e.Idrobo)
                    .HasName("PRIMARY");

                entity.ToTable("robos");

                entity.Property(e => e.Idrobo)
                    .HasColumnName("IDRobo")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Apellido)
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_general_ci");

                entity.Property(e => e.Cedula)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_general_ci");

                entity.Property(e => e.Desc)
                    .IsRequired()
                    .HasColumnName("Desc.")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_general_ci");

                entity.Property(e => e.Fecha).HasColumnType("date");

                entity.Property(e => e.Idprovincia)
                    .HasColumnName("IDProvincia")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Lat).HasColumnType("float(100,30)");

                entity.Property(e => e.Lon).HasColumnType("float(100,30)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_general_ci");

                entity.Property(e => e.UbicacionRobo)
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_general_ci");

                entity.Property(e => e.Valor).HasColumnType("int(11)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
